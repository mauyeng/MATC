package her_MidTerm;

/*
Jimmy Her
ITDEV-110
Mid-Term Assignment
 */
public class controller {
    
    double a;
    view view = new view();
    model model = new model();
    
    public void run(){
        view.displayDirections();
        do{
        a = view.inputScore();
        
        model.setAverage(a);
        model.setCount();
     
        
        view.displayAverage(model.getCount(), model.getAverage());
}
while(view.again()==true);
        view.goodBye(model.getCount(), model.getAverage());
    }

    
}
