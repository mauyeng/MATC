package her_MidTerm;
import java.util.Scanner;

/*
Jimmy Her
ITDEV-110
Mid-Term Assignment
 */


public class view {
    Scanner input = new Scanner(System.in);
    public void displayDirections(){
        System.out.println("This applicaion allows a user to calculate the average for as many sets of grading scores as the user would like"); //prints out the motive for the viewer.
        
    }
    public double inputScore(){
        
        System.out.println("Enter grade score: ");
        return input.nextDouble();
        
    }
    
    public void displayAverage(double count, double Avg){
        System.out.println("\n\nNumber of scores entered: \t" + count);
        System.out.println("Average of all scores:\t"+Avg);
    }
    
    public boolean again(){
        boolean again=true;
        int num=1; //assuming they would want to run the program again.
        System.out.println("\n\nwould you like to enter more scores? (1) Yes (0) No\n");
        num = input.nextInt();
        if(num==0){
            again = false;
        }
        return again;
    }
    public static void goodBye(double a, double b){
        System.out.println("Final Average: " + b);
        System.out.println("Final Count: " + a);
    }
}
