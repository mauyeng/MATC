package her_MidTerm;

/*
Jimmy Her
ITDEV-110
Mid-Term Assignment
 */
public class model {
    private double score=0;
      private double count=0;
      
      public double getCount(){
          return count;
      }
      
      public void setAverage(double newScore){
          score = score + newScore;
      }
      public void setCount(){
          count++;
      }
      public double getAverage(){
          return score/count;
      }
}
