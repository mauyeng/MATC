package her_MidTerm;

/*
Jimmy Her
ITDEV-110
Mid-Term Assignment
 */
public class main {

    public static void main(String[] args){
    controller controller = new controller();
    controller.run();
    
    }
}
