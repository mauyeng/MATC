package her_PracticeObjects;

public class MathFun {
    private double calc1;
    private double calc2;

    public MathFun(double num1, double num2) {
        calc1 = num1;
        calc2 = num2;
    }

    public double getNumber1(){
        System.out.println("\tgetNumber1 returning is "+calc2);
return calc1;
    }
    public void setNumber1(double n1){
        calc1=n1;
        System.out.println("\tgetNumber1 setting is "+calc1);
    }
    public double getNumber2(){
        System.out.println("\tgetNumber2 returning is "+calc2);
return calc2;
    }
    public void setNumber2(double n2){
        calc2 = n2;
        System.out.println("\tgetNumber2 setting is "+calc2);
    }
    public double multiplyThem(){
        System.out.println("\treturning product is "+calc1);

return(calc1*calc2);
    }
    public double addThem(){
return(calc1+calc2);

    }
}
