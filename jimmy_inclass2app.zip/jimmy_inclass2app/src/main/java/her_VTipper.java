package jimmy_inclass2app;

import java.util.Scanner;

public class her_VTipper {
    //  Jimmy Her | ITDEV-110-004 | Assignment #4

    public static void main(String[] args) {
        /*
         * This program calculates tip percentage of a
         * total to see how much tip would be.
         * The results will end with the Restaurant name,
         * total, total without tip, and the final total.
         * It can restart over if user want to calculate another tip.
         */
        Scanner scanner = new Scanner(System.in);
        int exit = 0;
        while (exit < 5) {
            Tipper.inputScreen();
            Tipper.tipCalc();
            System.out.println("Do you want to continue? If yes, type \"0\". If not, type \"6\"");
            exit = scanner.nextInt();

        }

    }

}