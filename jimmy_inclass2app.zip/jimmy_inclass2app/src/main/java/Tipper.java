package jimmy_inclass2app;
import java.util.Random;
import java.util.Scanner;
//Jimmy Her, ITDEV-110-004, Assignment 4
public class Tipper{
    private static String restaurantName;
    private static double total;
    private static int tip;
    private static double tipRatio;
    private static double finalTotal;
    private static int exit;

    public static void inputScreen() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("What is the Restaurant name?: ");
        restaurantName = scanner.next();
        restaurantName+=scanner.nextLine();
        System.out.print("Enter the cost of the meal?: ");
        total = scanner.nextDouble();

            }
    public static void tipCalc(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter % to tip: ");
        tip = scanner.nextInt();
        tipRatio = tip / 100.0;
        finalTotal = total + (total * tipRatio);
        System.out.println("The restaurant name is " + restaurantName + ". Total bill without tip is " + total + ". The tip amount is "+(finalTotal-total) +". The total bill is "+finalTotal);


    }


}